package com.W1_AOP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week1AopHwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week1AopHwApplication.class, args);
	}

}
