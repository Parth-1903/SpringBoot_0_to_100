package com.W1_AOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week1AopHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
