package com.codingshuttle.ecommerce.order_service.entity;

public enum OrderStatus {
    CONFIRMED, CANCELLED, PENDING, DELIVERED
}
