package com.week_3_ecommerce.discovery_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
